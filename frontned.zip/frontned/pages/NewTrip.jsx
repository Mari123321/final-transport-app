import React from "react";

const NewTrip = () => {
  return (
    <div>
      <h2>New Trip Page</h2>
      <p>This is where you will add new trips.</p>
    </div>
  );
};

export default NewTrip;
