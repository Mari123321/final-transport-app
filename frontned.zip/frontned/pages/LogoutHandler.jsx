import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const LogoutHandler = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Clear localStorage or any login tokens
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("user");

    // Navigate to login page
    navigate("/login");
  }, [navigate]);

  return null; // Nothing to render
};

export default LogoutHandler;
