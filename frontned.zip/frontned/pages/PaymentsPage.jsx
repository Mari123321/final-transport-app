import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Box,
  Typography,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Snackbar,
  Alert,
} from "@mui/material";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";

const PaymentsPage = () => {
  const [clients, setClients] = useState([]);
  const [selectedClient, setSelectedClient] = useState("");
  const [payments, setPayments] = useState([]);
  const [notification, setNotification] = useState({
    open: false,
    message: "",
    severity: "info",
  });

  useEffect(() => {
    fetchClients();
  }, []);

  useEffect(() => {
    fetchPayments(selectedClient);
  }, [selectedClient]);

  const fetchClients = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/clients");
      setClients(res.data);
    } catch (e) {
      console.error("Failed to fetch clients", e);
    }
  };

  const fetchPayments = async (clientId) => {
    try {
      const url = clientId
        ? `http://localhost:5000/api/payments?clientId=${clientId}`
        : "http://localhost:5000/api/payments";
      const res = await axios.get(url);
      setPayments(res.data);

      // Show notification if any payments have pending balance
      const anyPending = res.data.some((p) => p.paidAmount < p.totalAmount);
      if (anyPending) {
        setNotification({
          open: true,
          message: "Some payments have pending balance.",
          severity: "warning",
        });
      } else {
        setNotification({
          open: true,
          message: "All payments fully cleared!",
          severity: "success",
        });
      }
    } catch (e) {
      console.error("Failed to fetch payments", e);
      setNotification({
        open: true,
        message: "Failed to fetch payments",
        severity: "error",
      });
    }
  };

  const handleClientChange = (e) => {
    setSelectedClient(e.target.value);
  };

  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
  };

  const formatCurrency = (val) => {
    if (val === undefined || val === null || isNaN(Number(val))) return "—";
    return Number(val).toLocaleString("en-IN", {
      style: "currency",
      currency: "INR",
    });
  };

  return (
    <Box p={3}>
      <Typography variant="h4" gutterBottom>
        Payments Management
      </Typography>

      <FormControl fullWidth sx={{ mb: 3 }}>
        <InputLabel id="client-select-label">Filter by Client</InputLabel>
        <Select
          labelId="client-select-label"
          value={selectedClient}
          label="Filter by Client"
          onChange={handleClientChange}
        >
          <MenuItem value="">All Clients</MenuItem>
          {clients.map((c) => (
            <MenuItem key={c.clientId} value={c.clientId}>
              {c.name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Client</TableCell>
            <TableCell>Total Amount</TableCell>
            <TableCell>Paid Amount</TableCell>
            <TableCell>Balance</TableCell>
            <TableCell>Status</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {payments.length === 0 ? (
            <TableRow>
              <TableCell colSpan={5} align="center">
                No payments found
              </TableCell>
            </TableRow>
          ) : (
            payments.map(
              ({
                paymentId,
                clientName,
                totalAmount,
                paidAmount,
                balanceAmount,
              }) => {
                const isPending = paidAmount < totalAmount;
                return (
                  <TableRow
                    key={paymentId}
                    sx={{ backgroundColor: isPending ? "#fff3e0" : "inherit" }}
                  >
                    <TableCell>{clientName}</TableCell>
                    <TableCell>{formatCurrency(totalAmount)}</TableCell>
                    <TableCell>{formatCurrency(paidAmount)}</TableCell>
                    <TableCell>{formatCurrency(balanceAmount)}</TableCell>
                    <TableCell>
                      {isPending ? (
                        <Typography color="warning.main" fontWeight="bold">
                          Pending
                        </Typography>
                      ) : (
                        <CheckCircleOutlineIcon color="success" />
                      )}
                    </TableCell>
                  </TableRow>
                );
              }
            )
          )}
        </TableBody>
      </Table>

      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={handleCloseNotification}
      >
        <Alert
          onClose={handleCloseNotification}
          severity={notification.severity}
          variant="filled"
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default PaymentsPage;
