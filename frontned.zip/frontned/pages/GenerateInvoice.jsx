import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  Typography,
  Paper,
  TextField,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Checkbox,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";

const toISODate = (str) => {
  if (!str) return "";
  if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;
  if (/^\d{2}-\d{2}-\d{4}$/.test(str)) {
    const [dd, mm, yyyy] = str.split("-");
    return `${yyyy}-${mm}-${dd}`;
  }
  return str;
};

const numberOrZero = (v) => {
  const n = typeof v === "string" ? v.trim() : v;
  const parsed = parseFloat(n);
  return Number.isFinite(parsed) ? parsed : 0;
};

const GenerateInvoicePage = () => {
  const [clients, setClients] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [loadingInvoices, setLoadingInvoices] = useState(false);
  const [openForm, setOpenForm] = useState(false);
  const [selectedInvoices, setSelectedInvoices] = useState([]);

  const navigate = useNavigate();

  const [data, setData] = useState({
    invoiceNo: "",
    invoiceDate: "",
    dispatchDate: "",
    clientId: "",
    vehicleId: "",
    particulars: "",
    actualQty: "",
    minChargeQty: "",
    ratePerTonne: "",
    totalAmount: "0.00",
  });

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/api/clients");
        setClients(Array.isArray(res.data) ? res.data : res.data.data || []);
      } catch (err) {
        console.error("Error fetching clients:", err);
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/api/vehicles");
        let vehiclesArr = [];
        if (Array.isArray(res.data)) vehiclesArr = res.data;
        else if (res.data && Array.isArray(res.data.data)) vehiclesArr = res.data.data;
        setVehicles(vehiclesArr);
      } catch (err) {
        console.error("Error fetching vehicles:", err);
        setVehicles([]);
      }
    })();
  }, []);

  const fetchInvoices = async () => {
    setLoadingInvoices(true);
    try {
      let url = "/api/invoices";
      const params = [];
      if (data.clientId) params.push(`clientId=${data.clientId}`);
      if (data.vehicleId) params.push(`vehicleId=${data.vehicleId}`);
      if (params.length) url += `?${params.join("&")}`;

      const res = await api.get(url);
      setInvoices(Array.isArray(res.data) ? res.data : res.data.data || []);
    } catch (err) {
      console.error("Error fetching invoices:", err);
    } finally {
      setLoadingInvoices(false);
    }
  };

  useEffect(() => {
    fetchInvoices();
  }, [data.clientId, data.vehicleId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setData((prev) => {
      let updated = { ...prev, [name]: value };
      if (name === "clientId" || name === "vehicleId") {
        updated[name] = value === "" ? "" : Number(value);
      }
      if (name === "actualQty" && (prev.minChargeQty === "" || prev.minChargeQty === null)) {
        updated.minChargeQty = value;
      }
      if (["actualQty", "minChargeQty", "ratePerTonne"].includes(name)) {
        const actual = numberOrZero(name === "actualQty" ? value : updated.actualQty);
        const minCharge = numberOrZero(name === "minChargeQty" ? value : updated.minChargeQty);
        const rate = numberOrZero(name === "ratePerTonne" ? value : updated.ratePerTonne);
        const chargeQty = Math.max(actual, minCharge);
        updated.totalAmount = (chargeQty * rate).toFixed(2);
      }
      return updated;
    });
  };

  const resetForm = () =>
    setData({
      invoiceNo: "",
      invoiceDate: "",
      dispatchDate: "",
      clientId: "",
      vehicleId: "",
      particulars: "",
      actualQty: "",
      minChargeQty: "",
      ratePerTonne: "",
      totalAmount: "0.00",
    });

  const handleSubmit = async () => {
    if (data.clientId === "" || isNaN(data.clientId)) {
      alert("Please select a client.");
      return;
    }
    if (!data.invoiceDate) {
      alert("Please select invoice date.");
      return;
    }
    if (data.vehicleId === "" || isNaN(data.vehicleId)) {
      alert("Please select a vehicle.");
      return;
    }

    try {
      const actualQtyNum = numberOrZero(data.actualQty);
      const minChargeQtyNum = data.minChargeQty === "" || data.minChargeQty === null ? actualQtyNum : numberOrZero(data.minChargeQty);
      const ratePerTonneNum = numberOrZero(data.ratePerTonne);
      const chargeQty = Math.max(actualQtyNum, minChargeQtyNum);
      const computedTotal = (chargeQty * ratePerTonneNum).toFixed(2);

      const payload = {
        invoice_no: data.invoiceNo,
        invoice_date: toISODate(data.invoiceDate),
        dispatch_date: data.dispatchDate ? toISODate(data.dispatchDate) : toISODate(data.invoiceDate),
        client_id: data.clientId,
        vehicle_id: data.vehicleId,
        particulars: data.particulars,
        qty: actualQtyNum,
        min_charge_qty: minChargeQtyNum,
        rate: ratePerTonneNum,
        total_amount: computedTotal,
      };

      const response = await api.post("/api/invoices", payload);

      if (response.status === 201 || response.status === 200) {
        alert("Invoice generated successfully!");
        await fetchInvoices();
        setOpenForm(false);
        resetForm();
      } else {
        alert("Failed to generate invoice. Try again.");
      }
    } catch (e) {
      console.error("Error generating invoice:", e);
      alert("Error generating invoice. Check console for details.");
    }
  };

  const toggleSelectInvoice = (invoiceId) => {
    setSelectedInvoices((prev) => {
      if (prev.includes(invoiceId)) {
        return prev.filter((id) => id !== invoiceId);
      } else {
        return [...prev, invoiceId];
      }
    });
  };

  const handleBulkDelete = async () => {
    if (selectedInvoices.length === 0) {
      alert("Please select at least one invoice to delete.");
      return;
    }
    if (!window.confirm(`Are you sure you want to delete ${selectedInvoices.length} invoices?`)) return;

    try {
      await api.delete("/api/invoices/bulk-delete", { data: { invoiceIds: selectedInvoices } });
      alert(`${selectedInvoices.length} invoices deleted successfully.`);
      setSelectedInvoices([]);
      await fetchInvoices();
    } catch (err) {
      console.error("Error during bulk delete:", err);
      alert("Failed to delete invoices.");
    }
  };

  return (
    <Box p={3}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h4">Generate Invoice</Typography>
        <Stack direction="row" spacing={2}>
          <Button variant="contained" color="primary" onClick={() => setOpenForm(true)}>
            + New Invoice
          </Button>
          <Button variant="contained" color="secondary" onClick={() => navigate("/bills")}>
            View Bills
          </Button>
          <Button
            variant="contained"
            color="error"
            disabled={selectedInvoices.length === 0}
            onClick={handleBulkDelete}
          >
            Delete Selected
          </Button>
        </Stack>
      </Stack>

      {/* Invoice Creation Dialog */}
      <Dialog open={openForm} onClose={() => setOpenForm(false)} fullWidth maxWidth="sm">
        <DialogTitle>New Invoice</DialogTitle>
        <DialogContent dividers>
          {/* Client Select */}
          <FormControl fullWidth margin="normal" required>
            <InputLabel shrink>Client *</InputLabel>
            <Select
              name="clientId"
              value={data.clientId}
              onChange={handleChange}
              displayEmpty
              required
            >
              <MenuItem value="">
                <em>Select client</em>
              </MenuItem>
              {clients.map((c) => (
                <MenuItem key={c.client_id || c.id} value={Number(c.client_id || c.id)}>
                  {c.client_name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          {/* Vehicle Select */}
          <FormControl fullWidth margin="normal" required>
            <InputLabel shrink>Vehicle *</InputLabel>
            <Select
              name="vehicleId"
              value={data.vehicleId}
              onChange={handleChange}
              displayEmpty
              required
            >
              <MenuItem value="">
                <em>Select vehicle</em>
              </MenuItem>
              {vehicles.map((v) => (
                <MenuItem key={v.vehicle_id || v.id} value={Number(v.vehicle_id || v.id)}>
                  {v.vehicle_number}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          {/* Other Fields */}
          <FormControl fullWidth margin="normal">
            <TextField label="Invoice Number" name="invoiceNo" value={data.invoiceNo} onChange={handleChange} />
          </FormControl>
          <FormControl fullWidth margin="normal" required>
            <TextField
              label="Invoice Date *"
              name="invoiceDate"
              type="date"
              value={data.invoiceDate}
              onChange={handleChange}
              InputLabelProps={{ shrink: true }}
              required
            />
          </FormControl>
          <FormControl fullWidth margin="normal">
            <TextField
              label="Dispatch Date"
              name="dispatchDate"
              type="date"
              value={data.dispatchDate}
              onChange={handleChange}
              InputLabelProps={{ shrink: true }}
            />
          </FormControl>
          <FormControl fullWidth margin="normal">
            <TextField label="Particulars" name="particulars" value={data.particulars} onChange={handleChange} />
          </FormControl>
          <FormControl fullWidth margin="normal">
            <TextField
              type="number"
              label="Actual Quantity"
              name="actualQty"
              value={data.actualQty}
              onChange={handleChange}
              inputProps={{ min: 0, step: "0.01" }}
            />
          </FormControl>
          <FormControl fullWidth margin="normal">
            <TextField
              type="number"
              label="Minimum Charge Quantity"
              name="minChargeQty"
              placeholder="Defaults to Actual Quantity"
              value={data.minChargeQty === "" ? data.actualQty : data.minChargeQty}
              onChange={handleChange}
              inputProps={{ min: 0, step: "0.01" }}
            />
          </FormControl>
          <FormControl fullWidth margin="normal">
            <TextField
              type="number"
              label="Rate Per Tonne"
              name="ratePerTonne"
              value={data.ratePerTonne}
              onChange={handleChange}
              inputProps={{ min: 0, step: "0.01" }}
            />
          </FormControl>
          <Typography variant="h6" mt={2}>
            Total Amount: ₹{data.totalAmount || "0.00"}
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenForm(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSubmit}>Generate</Button>
        </DialogActions>
      </Dialog>

      {/* Invoice Table */}
      <Typography variant="h5" mb={2} mt={4}>
        Generated Invoices
      </Typography>
      <Paper>
        {loadingInvoices ? (
          <Typography p={2} align="center">Loading invoices...</Typography>
        ) : invoices.length === 0 ? (
          <Typography p={2} align="center">No invoices generated yet.</Typography>
        ) : (
          <Table>
            <TableHead>
              <TableRow>
                <TableCell padding="checkbox">
                  <Checkbox
                    indeterminate={selectedInvoices.length > 0 && selectedInvoices.length < invoices.length}
                    checked={invoices.length > 0 && selectedInvoices.length === invoices.length}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedInvoices(invoices.map(inv => inv.invoice_id || inv.id));
                      } else {
                        setSelectedInvoices([]);
                      }
                    }}
                  />
                </TableCell>
                <TableCell>S.No</TableCell>
                <TableCell>Invoice No</TableCell>
                <TableCell>Invoice Date</TableCell>
                <TableCell>Dispatch Date</TableCell>
                <TableCell>Client</TableCell>
                <TableCell>Vehicle</TableCell>
                <TableCell>Particulars</TableCell>
                <TableCell>Actual Qty</TableCell>
                <TableCell>Min. Charge Qty</TableCell>
                <TableCell>Rate/Tonne</TableCell>
                <TableCell>Total Amount</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {invoices.map((inv, idx) => {
                const clientName =
                  inv.client?.client_name ||
                  clients.find(c => (c.client_id || c.id) === inv.clientId)?.client_name ||
                  "-";
                const vehicleNum =
                  inv.vehicle?.vehicle_number ||
                  vehicles.find(v => (v.vehicle_id || v.id) === inv.vehicleId)?.vehicle_number ||
                  "-";

                const invId = inv.invoice_id || inv.id;
                return (
                  <TableRow key={invId} hover>
                    <TableCell padding="checkbox">
                      <Checkbox
                        checked={selectedInvoices.includes(invId)}
                        onChange={() => toggleSelectInvoice(invId)}
                      />
                    </TableCell>
                    <TableCell>{idx + 1}</TableCell>
                    <TableCell>{inv.invoice_no}</TableCell>
                    <TableCell>{inv.invoice_date}</TableCell>
                    <TableCell>{inv.dispatch_date}</TableCell>
                    <TableCell>{clientName}</TableCell>
                    <TableCell>{vehicleNum}</TableCell>
                    <TableCell>{inv.particulars}</TableCell>
                    <TableCell>{inv.qty ?? inv.actual_qty}</TableCell>
                    <TableCell>{inv.min_charge_qty}</TableCell>
                    <TableCell>{inv.rate ?? inv.rate_per_tonne}</TableCell>
                    <TableCell>₹{inv.totalAmount ?? inv.total_amount}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </Paper>
    </Box>
  );
};

export default GenerateInvoicePage;
