// frontend/src/pages/BillsPage.jsx
import React, { useEffect, useState } from "react";
import {
  Box, Typography, Table, TableHead, TableBody, TableRow,
  TableCell, Paper, IconButton, Checkbox, Switch, TextField, Button
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import GetAppIcon from "@mui/icons-material/GetApp";
import EditIcon from "@mui/icons-material/Edit";
import SaveIcon from "@mui/icons-material/Save";
import axios from "axios";

const API = "http://localhost:5000/api/invoices";

const BillsPage = () => {
  const [bills, setBills] = useState([]);
  const [selected, setSelected] = useState([]);
  const [editedRow, setEditedRow] = useState(null);
  const [editedMinQty, setEditedMinQty] = useState({});

  useEffect(() => { fetchBills(); }, []);

  const fetchBills = async () => {
    try {
      const res = await axios.get(API);
      setBills(res.data);
    } catch (err) {
      console.error("Error fetching bills:", err);
    }
  };

  const toggleSelect = (id) => {
    setSelected(prev => (
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    ));
  };

  const toggleSelectAll = () => {
    if (selected.length === bills.length) setSelected([]);
    else setSelected(bills.map(b => b.invoice_id || b.id));
  };

  const handleMinQtyChange = (id, value) => {
    setEditedMinQty(prev => ({ ...prev, [id]: value }));
  };

  const saveMinQty = async (id) => {
    try {
      const minQtyNum = Number(editedMinQty[id]);
      if (isNaN(minQtyNum)) {
        alert("Please enter a valid number");
        return;
      }
      await axios.put(`${API}/${id}`, { min_charge_qty: minQtyNum });
      setEditedRow(null);
      fetchBills();
    } catch (err) {
      alert("Failed to update minimum quantity");
    }
  };

  const handlePaymentStatusChange = async (id, status) => {
    try {
      await axios.put(`${API}/${id}`, { payment_status: status });
      fetchBills();
    } catch (err) {
      alert("Failed to update payment status");
    }
  };

  const deleteBill = async (id) => {
    if (!window.confirm("Are you sure you want to delete this bill?")) return;
    try {
      await axios.delete(`${API}/${id}`);
      fetchBills();
    } catch (err) {
      alert("Failed to delete bill");
    }
  };

  const downloadPDF = (id) => {
    window.open(`${API}/${id}/pdf`, "_blank");
  };

  return (
    <Box p={3}>
      <Box display="flex" justifyContent="space-between" mb={2}>
        <Typography variant="h4">Bills</Typography>
        <Button
          variant="outlined"
          color="error"
          disabled={!selected.length}
          onClick={async () => {
            await axios.post(`${API}/bulk-delete`, { ids: selected });
            fetchBills();
            setSelected([]);
          }}
        >
          Delete Selected
        </Button>
      </Box>

      <Paper elevation={3}>
        <Table sx={{ border: "1px solid #ddd" }}>
          <TableHead>
            <TableRow sx={{ backgroundColor: "#f5f5f5" }}>
              <TableCell padding="checkbox">
                <Checkbox
                  checked={selected.length === bills.length && bills.length > 0}
                  indeterminate={selected.length > 0 && selected.length < bills.length}
                  onChange={toggleSelectAll}
                />
              </TableCell>
              <TableCell>S.No</TableCell>
              <TableCell>Invoice No</TableCell>
              <TableCell>Invoice Date</TableCell>
              <TableCell>Dispatch Date</TableCell>
              <TableCell>Client</TableCell>
              <TableCell>Vehicle</TableCell>
              <TableCell>Particulars</TableCell>
              <TableCell>Actual Qty</TableCell>
              <TableCell>Min Charge Qty</TableCell>
              <TableCell>Rate/Tonne</TableCell>
              <TableCell>Total Amount</TableCell>
              <TableCell>Payment Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {bills.length === 0 ? (
              <TableRow>
                <TableCell colSpan={14} align="center">No bills found.</TableCell>
              </TableRow>
            ) : (
              bills.map((bill, idx) => {
                const id = bill.invoice_id || bill.id;
                const isEditing = editedRow === id;

                return (
                  <TableRow key={id} selected={selected.includes(id)}>
                    <TableCell padding="checkbox">
                      <Checkbox
                        checked={selected.includes(id)}
                        onChange={() => toggleSelect(id)}
                      />
                    </TableCell>
                    <TableCell>{idx + 1}</TableCell>
                    <TableCell>{bill.invoice_no || "-"}</TableCell>
                    <TableCell>{bill.invoice_date || "-"}</TableCell>
                    <TableCell>{bill.dispatch_date || "-"}</TableCell>
                    <TableCell>{bill.client?.client_name || "-"}</TableCell>
                    <TableCell>{bill.vehicle?.vehicle_number || "-"}</TableCell>
                    <TableCell>{bill.particulars || "-"}</TableCell>
                    <TableCell>{bill.qty || 0}</TableCell>

                    <TableCell>
                      {isEditing ? (
                        <>
                          <TextField
                            type="number"
                            value={editedMinQty[id] ?? bill.min_charge_qty ?? 0}
                            size="small"
                            onChange={e => handleMinQtyChange(id, e.target.value)}
                            sx={{ width: "80px", mr: 1 }}
                          />
                          <IconButton color="success" onClick={() => saveMinQty(id)}>
                            <SaveIcon />
                          </IconButton>
                        </>
                      ) : (
                        <>
                          {bill.min_charge_qty ?? 0}
                          <IconButton
                            size="small"
                            sx={{ ml: 1 }}
                            onClick={() => {
                              setEditedRow(id);
                              setEditedMinQty({ [id]: bill.min_charge_qty ?? 0 });
                            }}
                          >
                            <EditIcon fontSize="small" />
                          </IconButton>
                        </>
                      )}
                    </TableCell>

                    <TableCell>{bill.rate || 0}</TableCell>
                    <TableCell>{bill.total_amount || 0}</TableCell>

                    <TableCell>
                      <Switch
                        checked={bill.payment_status === "Paid"}
                        onChange={(e) =>
                          handlePaymentStatusChange(id, e.target.checked ? "Paid" : "Pending")
                        }
                        color="primary"
                      />
                      <span style={{ marginLeft: 8 }}>
                        {bill.payment_status || "Pending"}
                      </span>
                    </TableCell>

                    <TableCell>
                      <IconButton onClick={() => deleteBill(id)} title="Delete">
                        <DeleteIcon />
                      </IconButton>
                      <IconButton onClick={() => downloadPDF(id)} title="Download PDF">
                        <GetAppIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  );
};

export default BillsPage;
