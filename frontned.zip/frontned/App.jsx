// src/App.jsx
import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  useLocation,
} from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { ThemeProvider, createTheme, CssBaseline } from "@mui/material";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// Components
import Sidebar from "./components/Sidebar";
import Topbar from "./components/Topbar";
import AnimatedPage from "./components/AnimatedPage";

// Pages
import Dashboard from "./pages/Dashboard";
import ClientDashboard from "./pages/ClientDashboard";
import ClientsPage from "./pages/ClientsPage";
import DriversPage from "./pages/DriversPage";
import GoodsPage from "./pages/GoodsPage";
import TripsPage from "./pages/TripsPage";
import PaymentsPage from "./pages/PaymentsPage";
import ExpensesPage from "./pages/ExpensesPage";
import InvoicesPage from "./pages/InvoicesPage";
import VehiclesPage from "./pages/VehiclesPage";
import AddVehiclePage from "./pages/AddVehiclePage";
import TripsForm from "./pages/TripsForm";
import AdvancesPage from "./pages/AdvancesPage";
import ProfilePage from "./pages/ProfilePage";
import AdminAnalytics from "./pages/AdminAnalytics";
import BillsPage from "./pages/BillsPage";
import LogoutHandler from "./pages/LogoutHandler";
import GenerateInvoice from "./pages/GenerateInvoice";

// ==========================
// THEME CONFIGURATION
// ==========================
const theme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#1976d2",
    },
    secondary: {
      main: "#ff4081",
    },
    background: {
      default: "#f4f6f8",
    },
  },
  typography: {
    fontFamily: `'Poppins', 'Roboto', 'Arial', sans-serif`,
    fontWeightMedium: 500,
  },
});

// ==========================
// MAIN APP CONTENT
// ==========================
const AppContent = () => {
  const location = useLocation();

  return (
    <div
      style={{
        height: "100vh",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
      }}
    >
      {/* Topbar */}
      <Topbar />

      {/* Body Layout */}
      <div
        style={{
          display: "flex",
          flex: 1,
          overflow: "hidden",
        }}
      >
        {/* Sidebar */}
        <Sidebar />

        {/* Main Content */}
        <main
          style={{
            flex: 1,
            overflowY: "auto",
            overflowX: "hidden", // ✅ prevent horizontal scroll
            padding: "40px 24px 100px 24px", // ✅ spacing
            WebkitOverflowScrolling: "touch",
          }}
          className="no-scrollbar"
        >
          <AnimatePresence mode="wait">
            <Routes location={location} key={location.pathname}>
              <Route path="/" element={<Navigate to="/dashboard" />} />
              <Route
                path="/dashboard"
                element={
                  <AnimatedPage>
                    <Dashboard />
                  </AnimatedPage>
                }
              />
              <Route
                path="/clients/dashboard"
                element={
                  <AnimatedPage>
                    <ClientDashboard />
                  </AnimatedPage>
                }
              />
              <Route
                path="/clients"
                element={
                  <AnimatedPage>
                    <ClientsPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/drivers"
                element={
                  <AnimatedPage>
                    <DriversPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/goods"
                element={
                  <AnimatedPage>
                    <GoodsPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/trips"
                element={
                  <AnimatedPage>
                    <TripsPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/payments"
                element={
                  <AnimatedPage>
                    <PaymentsPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/expenses"
                element={
                  <AnimatedPage>
                    <ExpensesPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/invoices"
                element={
                  <AnimatedPage>
                    <InvoicesPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/vehicles"
                element={
                  <AnimatedPage>
                    <VehiclesPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/vehicles/add"
                element={
                  <AnimatedPage>
                    <AddVehiclePage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/advances"
                element={
                  <AnimatedPage>
                    <AdvancesPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/trips/add"
                element={
                  <AnimatedPage>
                    <TripsForm />
                  </AnimatedPage>
                }
              />
              <Route
                path="/profile"
                element={
                  <AnimatedPage>
                    <ProfilePage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/admin-analytics"
                element={
                  <AnimatedPage>
                    <AdminAnalytics />
                  </AnimatedPage>
                }
              />
              <Route
                path="/bills"
                element={
                  <AnimatedPage>
                    <BillsPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/logout"
                element={
                  <AnimatedPage>
                    <LogoutHandler />
                  </AnimatedPage>
                }
              />
              <Route
                path="/generate-invoice"
                element={
                  <AnimatedPage>
                    <GenerateInvoice />
                  </AnimatedPage>
                }
              />
            </Routes>
          </AnimatePresence>
        </main>
      </div>

      {/* Toast Notifications */}
      <ToastContainer position="top-right" autoClose={3000} />
    </div>
  );
};

// ==========================
// APP WRAPPER
// ==========================
const App = () => (
  <ThemeProvider theme={theme}>
    <CssBaseline />
    <Router>
      <AppContent />
    </Router>
  </ThemeProvider>
);

export default App;
