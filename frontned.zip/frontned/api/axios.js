// src/api/axios.js
import axios from "axios";

// Use env when available: VITE_API_URL=http://localhost:5000
const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

const api = axios.create({
  baseURL: BASE_URL, // <- avoids calling Vite (5173)
  withCredentials: false,
  headers: {
    "Content-Type": "application/json",
  },
});

export default api;
