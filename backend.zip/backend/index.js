import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { sequelize } from './models/index.js'; 
import { startLicenseAlertJob } from './jobs/licenseAlerts.js';

// Import API routes
import userRoutes from './routes/userRoutes.js';
import clientRoutes from './routes/clientRoutes.js';
import driverRoutes from './routes/driverRoutes.js';
import vehicleRoutes from './routes/vehicleRoutes.js';
import tripRoutes from './routes/tripRoutes.js';
import invoiceRoutes from './routes/invoiceRoutes.js';
import expenseRoutes from './routes/expenseRoutes.js';
import paymentRoutes from './routes/paymentRoutes.js';
import advanceRoutes from './routes/advanceRoutes.js';
import transactionRoutes from './routes/transactionRoutes.js';
import distanceRoutes from './routes/distanceRoutes.js';
import dashboardRoutes from './routes/dashboardRoutes.js';
import notificationRoutes from './routes/notificationRoutes.js'; // ✅ use only route

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middlewares
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/users', userRoutes);
app.use('/api/clients', clientRoutes);
app.use('/api/drivers', driverRoutes);
app.use('/api/vehicles', vehicleRoutes);
app.use('/api/trips', tripRoutes);
app.use('/api/invoices', invoiceRoutes);
app.use('/api/distance', distanceRoutes);
app.use('/api/expenses', expenseRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/advances', advanceRoutes);
app.use('/api/transactions', transactionRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/notifications', notificationRoutes); // ✅ correct one

// Test route
app.get('/', (req, res) => {
  res.send('✅ Transport Management System API is running...');
});

// Sequelize DB sync and server start
(async () => {
  try {
    await sequelize.authenticate();
    console.log('🔗 Database connection established successfully.');

    await sequelize.sync({ alter: true });
    console.log('✅ Database synced successfully.');

    startLicenseAlertJob();

    app.listen(PORT, () => {
      console.log(`🚀 Server running on http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('❌ Database connection or sync failed:', err);
    process.exit(1);
  }
})();
