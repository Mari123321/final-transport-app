import express from 'express';
import { createBill, getAllBills, downloadBillPDF } from '../controllers/billController.js';

const router = express.Router();

router.post('/', createBill);
router.get('/', getAllBills);

router.put("/:id", updateInvoice);

router.get('/:id/pdf', downloadBillPDF);

export default router;
