import express from "express";
import { createOrFetchInvoice } from "../controllers/invoiceController.js";
import db from "../models/index.js";

const { Trip } = db;
const router = express.Router();

// Get distinct trip dates for a client
router.get("/trips/dates/:clientId", async (req, res) => {
  try {
    const { clientId } = req.params;

    const trips = await Trip.findAll({
      where: { client_id: clientId },
      attributes: [
        [
          Trip.sequelize.fn("DISTINCT", Trip.sequelize.fn("DATE", Trip.sequelize.col("date"))),
          "date",
        ],
      ],
      order: [["date", "ASC"]],
      raw: true,
    });

    const dates = trips.map(t => t.date);
    res.json(dates);
  } catch (error) {
    console.error("Error fetching trip dates:", error);
    res.status(500).json({ error: "Failed to fetch trip dates" });
  }
});

// Create or fetch invoice
router.post("/", createOrFetchInvoice);

export default router;
