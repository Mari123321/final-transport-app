import { Sequelize, DataTypes } from "sequelize";
import dotenv from "dotenv";

dotenv.config();

// Import models
import UserModel from "./userModel.js";
import ClientModel from "./clientModel.js";
import DriverModel from "./driver.js";
import VehicleModel from "./vehicle.js";
import TripModel from "./trip.js";
import InvoiceModel from "./invoice.js";
import InvoiceTripModel from "./invoiceTrip.js";
import ExpenseModel from "./expense.js";
import PaymentModel from "./payment.js";
import AdvanceModel from "./advance.js";
import TransactionModel from "./transaction.js";
import DispatchModel from "./dispatch.js";
import ExtraChargeModel from "./extraCharge.js";

// Initialize Sequelize
const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    dialect: "mysql",
    logging: false,
  }
);

// Initialize models
const User = UserModel(sequelize, DataTypes);
const Client = ClientModel(sequelize, DataTypes);
const Driver = DriverModel(sequelize, DataTypes);
const Vehicle = VehicleModel(sequelize, DataTypes);
const Trip = TripModel(sequelize, DataTypes);
const Invoice = InvoiceModel(sequelize, DataTypes);
const InvoiceTrip = InvoiceTripModel(sequelize, DataTypes);
const Expense = ExpenseModel(sequelize, DataTypes);
const Payment = PaymentModel(sequelize, DataTypes);
const Advance = AdvanceModel(sequelize, DataTypes);
const Transaction = TransactionModel(sequelize, DataTypes);
const Dispatch = DispatchModel(sequelize, DataTypes);
const ExtraCharge = ExtraChargeModel(sequelize, DataTypes);

/* Define Associations */

// Client ↔ Invoice (1-to-many)
Client.hasMany(Invoice, { foreignKey: "client_id", as: "invoices" });
Invoice.belongsTo(Client, { foreignKey: "client_id", as: "client" });

// Client ↔ Vehicle (1-to-many)
Client.hasMany(Vehicle, { foreignKey: "client_id", as: "vehicles" });
Vehicle.belongsTo(Client, { foreignKey: "client_id", as: "client" });

// Client ↔ Trip (1-to-many)
Client.hasMany(Trip, { foreignKey: "client_id", as: "trips" });
Trip.belongsTo(Client, { foreignKey: "client_id", as: "client" });

// Driver ↔ Trip (1-to-many)
Driver.hasMany(Trip, { foreignKey: "driver_id", as: "trips" });
Trip.belongsTo(Driver, { foreignKey: "driver_id", as: "driver" });

// Vehicle ↔ Trip (1-to-many)
Vehicle.hasMany(Trip, { foreignKey: "vehicle_id", as: "trips" });
Trip.belongsTo(Vehicle, { foreignKey: "vehicle_id", as: "vehicle" });

// Driver ↔ Vehicle (1-to-many)
Driver.hasMany(Vehicle, { foreignKey: "driver_id", as: "vehicles" });
Vehicle.belongsTo(Driver, { foreignKey: "driver_id", as: "driver" });

// Invoice ↔ Vehicle (1-to-many)
Vehicle.hasMany(Invoice, { foreignKey: "vehicle_id", as: "invoices" });
Invoice.belongsTo(Vehicle, { foreignKey: "vehicle_id", as: "vehicle" });

// Invoice ↔ Trip (many-to-many via InvoiceTrip)
Trip.belongsToMany(Invoice, {
  through: InvoiceTrip,
  foreignKey: "trip_id",
  otherKey: "invoice_id",
  as: "invoices",
});
Invoice.belongsToMany(Trip, {
  through: InvoiceTrip,
  foreignKey: "invoice_id",
  otherKey: "trip_id",
  as: "trips",
});

// Trip ↔ InvoiceTrip (1-to-many)
Trip.hasMany(InvoiceTrip, { foreignKey: "trip_id", as: "invoiceTrips" });
InvoiceTrip.belongsTo(Trip, { foreignKey: "trip_id", as: "trip" });

// Client ↔ Payment (1-to-many)
Client.hasMany(Payment, { foreignKey: "client_id", as: "payments" });
Payment.belongsTo(Client, { foreignKey: "client_id", as: "client" });

// Trip ↔ Payment (1-to-many)
Trip.hasMany(Payment, { foreignKey: "trip_id", as: "payments" });
Payment.belongsTo(Trip, { foreignKey: "trip_id", as: "trip" });

// Invoice ↔ Dispatch (1-to-many)
Invoice.hasMany(Dispatch, { foreignKey: "invoice_id", as: "dispatches" });
Dispatch.belongsTo(Invoice, { foreignKey: "invoice_id", as: "invoice" });

// Invoice ↔ ExtraCharge (1-to-many)
Invoice.hasMany(ExtraCharge, { foreignKey: "invoice_id", as: "extraCharges" });
ExtraCharge.belongsTo(Invoice, { foreignKey: "invoice_id", as: "invoice" });

// Diagnostic logs to confirm associations loaded correctly
console.log("Invoice associations:", Object.keys(Invoice.associations));
console.log("Vehicle associations:", Object.keys(Vehicle.associations));

/* Export Models and Sequelize */

export {
  sequelize,
  User,
  Client,
  Driver,
  Vehicle,
  Trip,
  Invoice,
  InvoiceTrip,
  Expense,
  Payment,
  Advance,
  Transaction,
  Dispatch,
  ExtraCharge,
};

export default {
  sequelize,
  User,
  Client,
  Driver,
  Vehicle,
  Trip,
  Invoice,
  InvoiceTrip,
  Expense,
  Payment,
  Advance,
  Transaction,
  Dispatch,
  ExtraCharge,
};
