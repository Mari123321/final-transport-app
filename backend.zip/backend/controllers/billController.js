import { Invoice, Client, Vehicle } from "../models/index.js";
import PDFDocument from "pdfkit";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const getAllBills = async (req, res) => {
  try {
    const bills = await Invoice.findAll({
      include: [
        { model: Client, as: "client", attributes: ["client_name"] },
        
      ],
      attributes: [
        ["invoice_id", "bill_id"],
        "invoice_no",
        ["invoice_date", "date"],
        "dispatch_date",
        "total_amount",
        "payment_status",
        "min_charge_qty",
        "qty",
        "rate",
        "particulars",
      ],
      order: [["invoice_date", "DESC"]],
    });
    res.status(200).json(bills);
  } catch (error) {
    console.error("Error fetching bills:", error);
    res.status(500).json({ message: "Failed to fetch bills" });
  }
};

export const updatePaymentStatus = async (req, res) => {
  try {
    const id = req.params.id;
    const { payment_status } = req.body;
    const invoice = await Invoice.findByPk(id);
    if (!invoice) return res.status(404).json({ message: "Invoice not found" });

    await invoice.update({ payment_status });
    res.json({ message: "Payment status updated", payment_status });
  } catch (error) {
    console.error("Error updating payment status:", error);
    res.status(500).json({ message: "Failed to update payment status" });
  }
};

export const updateMinChargeQty = async (req, res) => {
  try {
    const id = req.params.id;
    const { min_charge_qty } = req.body;

    const invoice = await Invoice.findByPk(id);
    if (!invoice) return res.status(404).json({ message: "Invoice not found" });

    await invoice.update({ min_charge_qty });
    res.json({ message: "Min charge quantity updated", min_charge_qty });
  } catch (error) {
    console.error("Error updating min_charge_qty:", error);
    res.status(500).json({ message: "Failed to update min charge quantity" });
  }
};

export const downloadBillPDF = async (req, res) => {
  try {
    const bill = await Invoice.findByPk(req.params.id, {
      include: [
        { model: Client, as: "client", attributes: ["client_name"] },
        
      ],
    });

    if (!bill) return res.status(404).json({ message: "Bill not found" });

    const doc = new PDFDocument({ margin: 40, size: "A4" });
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename=bill-${bill.invoice_no || bill.id}.pdf`);
    doc.pipe(res);

    doc.fontSize(16).font("Helvetica-Bold").text("R.K.S.BRO'S", { align: "center" });
    doc.fontSize(10).font("Helvetica").text(
      "Fleet Owners & Transport Contractors\nOld No 99 New No 47, G.A Road, 2nd Lane, Old Washermenpet, Ch-21\nPh: 044-25945913/25985558, Mob: 9841128061, 9841128064",
      { align: "center" }
    );
    doc.moveDown(1);

    doc.fontSize(11).font("Helvetica-Bold").text("BILL", { align: "center" });
    doc.moveDown(0.5);

    const yStart = doc.y;
    doc.fontSize(10).font("Helvetica-Bold").text("Invoice No:", 40, yStart);
    doc.font("Helvetica").text(bill.invoice_no || "-", 110, yStart);
    doc.font("Helvetica-Bold").text("Invoice Date:", 350, yStart);
    doc.font("Helvetica").text(bill.invoice_date || "-", 430, yStart);

    doc.font("Helvetica-Bold").text("To:", 40, yStart + 18);
    doc.font("Helvetica").text(bill.client?.client_name || "-", 110, yStart + 18);

    doc.moveDown(3);

    const tableTop = doc.y;
    const rowHeight = 20;
    const colWidths = [60, 80, 90, 60, 60, 60, 60];
    const headers = [
      "Date of Dispatch", "Vehicle No", "Particulars", "Actual Qty", "Min Qty", "Rate", "Amount"
    ];

    let x = 40;
    doc.font("Helvetica-Bold").fontSize(9);
    headers.forEach((header, i) => {
      doc.rect(x, tableTop, colWidths[i], rowHeight).stroke();
      doc.text(header, x + 2, tableTop + 6, { width: colWidths[i] - 4, align: "center" });
      x += colWidths[i];
    });

    let y = tableTop + rowHeight;
    x = 40;
    doc.font("Helvetica").fontSize(9);
    const row = [
      bill.dispatch_date || "-",
      bill.vehicle?.vehicle_number || "-",
      bill.particulars || "-",
      bill.qty || "-",
      bill.min_charge_qty || "-",
      bill.rate || "-",
      bill.total_amount ? `₹${bill.total_amount}` : "-"
    ];
    row.forEach((text, i) => {
      doc.rect(x, y, colWidths[i], rowHeight).stroke();
      doc.text(text?.toString() || "-", x + 2, y + 6, { width: colWidths[i] - 4, align: "center" });
      x += colWidths[i];
    });

    y += rowHeight + 10;
    doc.font("Helvetica-Bold").fontSize(10).text("TOTAL", 400, y);
    doc.font("Helvetica-Bold").fontSize(10).text(
      bill.total_amount ? `₹${bill.total_amount}` : "-",
      500, y, { align: "right" }
    );

    y += 40;
    doc.fontSize(9).font("Helvetica-Bold").text("Terms & Conditions", 40, y);
    doc.font("Helvetica").fontSize(8).text(
      "1. Subject to Chennai Jurisdiction.\n" +
      "2. Interest @ 24% per annum will be charged if not paid within due date from the date bill.\n" +
      "3. Payment should be made by a/c payee Cheque / draft payable at Chennai.",
      40, y + 12
    );

    doc.fontSize(9).font("Helvetica-Oblique").text(
      "This is a Computer Generated Invoice",
      40, 780, { align: "left" }
    );
    doc.fontSize(9).font("Helvetica-Bold").text(
      "For R.K.S. BRO'S\nAuthorized Signatory",
      400, 760, { align: "left" }
    );

    doc.end();
  } catch (err) {
    res.status(500).json({ message: "Error generating Bill PDF", error: err.message });
  }
};
