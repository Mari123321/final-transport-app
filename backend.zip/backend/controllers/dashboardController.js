import { Driver, Client, Vehicle, Trip, Invoice } from "../models/index.js";
import { Op } from "sequelize";

export const getDashboardStats = async (req, res) => {
  try {
    const totalDrivers = await Driver.count();
    const totalClients = await Client.count();
    const totalVehicles = await Vehicle.count();
    const totalTrips = await Trip.count();
    const totalInvoices = await Invoice.count();

    // Pending invoices total amount
    const pendingInvoices = await Invoice.findAll({
      where: { status: "Pending" },
      attributes: ["amount"]
    });

    const pendingAmount = pendingInvoices.reduce(
      (sum, inv) => sum + (parseFloat(inv.amount) || 0),
      0
    );

    res.json({
      drivers: totalDrivers,
      clients: totalClients,
      vehicles: totalVehicles,
      trips: totalTrips,
      invoices: totalInvoices,
      pendingAmount
    });
  } catch (error) {
    console.error("Error fetching dashboard stats:", error);
    res.status(500).json({ message: "Failed to fetch dashboard stats" });
  }
};
