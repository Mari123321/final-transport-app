// controllers/clientController.js
import { Client } from '../models/index.js';

// CREATE
export const createClient = async (req, res) => {
  try {
    const client = await Client.create(req.body);
    res.status(201).json(client);
  } catch (error) {
    res.status(500).json({ message: 'Failed to add client', error: error.message });
  }
};

// READ ALL
export const getAllClients = async (_req, res) => {
  try {
    const clients = await Client.findAll();
    res.status(200).json(clients);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch clients', error: error.message });
  }
};

// READ ONE
export const getClientById = async (req, res) => {
  try {
    const client = await Client.findByPk(req.params.id);
    if (!client) return res.status(404).json({ message: 'Client not found' });
    res.status(200).json(client);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch client', error: error.message });
  }
};

// UPDATE  ✅ uses id (not client_id)
export const updateClient = async (req, res) => {
  try {
    const [updated] = await Client.update(req.body, { where: { id: req.params.id } });
    if (updated) {
      const updatedClient = await Client.findByPk(req.params.id);
      res.status(200).json(updatedClient);
    } else {
      res.status(404).json({ message: 'Client not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Failed to update client', error: error.message });
  }
};

// DELETE (single)  ✅ uses id (not client_id)
export const deleteClient = async (req, res) => {
  try {
    const deleted = await Client.destroy({ where: { id: req.params.id } });
    if (deleted) {
      res.status(200).json({ message: 'Client deleted successfully' });
    } else {
      res.status(404).json({ message: 'Client not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete client', error: error.message });
  }
};

// BULK DELETE (Hulk mode)  ✅ accepts { ids: number[] }
export const bulkDeleteClients = async (req, res) => {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ message: 'ids must be a non-empty array' });
    }
    const deleted = await Client.destroy({ where: { id: ids } });
    res.status(200).json({ message: `${deleted} clients deleted successfully` });
  } catch (error) {
    res.status(500).json({ message: 'Failed to bulk delete clients', error: error.message });
  }
};
