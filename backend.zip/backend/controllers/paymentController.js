import { Client, Payment } from "../models/index.js";

// Get all payments, optionally filtered by clientId
export const getAllPayments = async (req, res) => {
  try {
    const { clientId } = req.query;
    const where = clientId ? { clientId } : {};

    const payments = await Payment.findAll({
      where,
      include: [{ model: Client, attributes: ["name"] }],
      order: [["createdAt", "DESC"]],
    });

    const result = payments.map((payment) => {
      const totalAmount = payment.totalAmount || 0;
      const paidAmount = payment.paidAmount || 0;
      return {
        paymentId: payment.id,
        clientId: payment.clientId,
        clientName: payment.Client?.name || "",
        totalAmount,
        paidAmount,
        balanceAmount: totalAmount - paidAmount,
      };
    });

    res.json(result);
  } catch (error) {
    console.error("Error getting payments:", error);
    res.status(500).json({ error: "Failed to get payments" });
  }
};

// Get payment by ID
export const getPaymentById = async (req, res) => {
  try {
    const { id } = req.params;
    const payment = await Payment.findByPk(id, { include: [{ model: Client }] });
    if (!payment) return res.status(404).json({ error: "Payment not found" });

    res.json(payment);
  } catch (error) {
    console.error("Error fetching payment:", error);
    res.status(500).json({ error: "Failed to fetch payment" });
  }
};

// Create new payment
export const createPayment = async (req, res) => {
  try {
    const newPayment = await Payment.create(req.body);
    res.status(201).json(newPayment);
  } catch (error) {
    console.error("Error creating payment:", error);
    res.status(500).json({ error: "Failed to create payment" });
  }
};

// Update payment by ID
export const updatePayment = async (req, res) => {
  try {
    const { id } = req.params;
    const payment = await Payment.findByPk(id);
    if (!payment) return res.status(404).json({ error: "Payment not found" });

    await payment.update(req.body);
    res.json(payment);
  } catch (error) {
    console.error("Error updating payment:", error);
    res.status(500).json({ error: "Failed to update payment" });
  }
};

// Delete payment by ID
export const deletePayment = async (req, res) => {
  try {
    const { id } = req.params;
    const payment = await Payment.findByPk(id);
    if (!payment) return res.status(404).json({ error: "Payment not found" });

    await payment.destroy();
    res.json({ message: "Payment deleted" });
  } catch (error) {
    console.error("Error deleting payment:", error);
    res.status(500).json({ error: "Failed to delete payment" });
  }
};

// Fetch all clients for filtering dropdown
export const fetchClients = async (req, res) => {
  try {
    const clients = await Client.findAll({
      attributes: ["clientId", "name"],
      order: [["name", "ASC"]],
    });
    res.json(clients);
  } catch (error) {
    console.error("Error fetching clients:", error);
    res.status(500).json({ error: "Failed to fetch clients" });
  }
};
